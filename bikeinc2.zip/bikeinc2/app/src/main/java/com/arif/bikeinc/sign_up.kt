package com.arif.bikeinc

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class sign_up : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_sign_up)
    }
}